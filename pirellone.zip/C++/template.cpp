int is_solvable(int M, int N, int **P) {
    // TODO
    return 42;
}
void solve(int M, int N, int **P, void switch_row(int i), void switch_col(int j)) {
    // TODO
}
