class Solution extends Skeleton {

    int is_solvable(int M, int N, int P[][]) {
        // TODO
        return 42;
    }
    void solve(int M, int N, int P[][], SolveCallbacks callbacks) {
        // TODO
    }
}
