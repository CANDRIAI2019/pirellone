def is_solvable(M, N, P):
    # TODO
    return 42
    pass

def solve(M, N, P, switch_row, switch_col):
    # TODO
    pass

