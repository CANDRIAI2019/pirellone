
pub fn is_solvable(M: i64, N: i64, P: Vec<Vec<i64>>) -> i64 {
    // TODO
    return 42;
}
pub fn solve(M: i64, N: i64, P: Vec<Vec<i64>>, switch_row: fn(i64), switch_col: fn(i64))  {
    // TODO
}
